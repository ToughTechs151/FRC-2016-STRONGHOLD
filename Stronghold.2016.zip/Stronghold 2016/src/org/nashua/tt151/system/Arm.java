/**
hhhh- * Code for articulating arm in elbow and shoulder joints 
 * 
 * @author Madeline Esp and Harrison Pound
 * @version 2/6/2016 (1.0)
 */

package org.nashua.tt151.system;
import org.nashua.tt151.lib.F310;
import edu.wpi.first.wpilibj.Talon;

public class Arm extends Subsystem{
	private static Arm INSTANCE = null;
		
	Talon shoulder = new Talon(0);
	Talon elbow = new Talon(1);
	
	private Arm(){}
	
	public static Arm getInstance(){
		if(INSTANCE == null){
			INSTANCE = new Arm();
		}
		return INSTANCE;
	}
	public void init(){}
	
	@Override
	public void operatorControl(F310 arm, F310 drive){
	
		double mult = getMultiplier(arm);
		double shoulder2 = arm.getLeftY() * mult;
		double elbow2 = arm.getRightY() * mult;
	
		set(shoulder2, elbow2);
		if(arm.getButton(F310.Button.B)) {
			elbow.set(0);
			shoulder.set(0); //Locks both elbow and shoulder joints
		}
		if(arm.getButton(F310.Button.LEFT_BUMPER)) {
			setShoulder(-.2); //Sets shoulder joint to 1/5 speed if left bumper is pressed
		}
		if (arm.getButton(F310.Button.RIGHT_BUMPER)) {
			setElbow(.2); //Sets elbow joint to 1/5 speed if right bumper is pressed
		}
	}
	
	private double getMultiplier(F310 arm){
		if(arm.getButton(F310.Button.LEFT_TRIGGER)) {
			return 0.25;
			} 
		else if (arm.getButton(F310.Button.RIGHT_TRIGGER)) {
			return 1;
			}
		else
			return 0.5;
	}
	
	public void set(double shoulder, double elbow){
		setShoulder(shoulder);
		setElbow(elbow);
	}
	
	private void setShoulder(double speed) {
		shoulder.set(speed);
	}
		
	private void setElbow(double speed) {
		elbow.set(speed);
	}
}
