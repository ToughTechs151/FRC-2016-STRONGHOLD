/**
 * Code for the drive system used by the robot 
 * 
 * @author Harrison Pound
 * @version 2/6/16 (1.0)
 */

package org.nashua.tt151.system;
import org.nashua.tt151.lib.F310;
import org.nashua.tt151.lib.F310.Axis;

import edu.wpi.first.wpilibj.Talon;

public class TankDrive extends Subsystem {
	static TankDrive INSTANCE = null;

	 Talon l1 = new Talon(0);
	 Talon l2 = new Talon(1);
	 Talon r1 = new Talon(2);
	 Talon r2 = new Talon(3);

	private TankDrive() {}

	public static TankDrive getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new TankDrive();
		}
		return INSTANCE;
	}


	@Override
	public void init() {
		
	}

	
		@Override
		public void operatorControl(F310 drive, F310 arm) {
	
			double left = drive.getLeftY();
			double right = drive.getRightY();
	
			set(right * getMultiplier(drive), getMultiplier(drive) * left);

		/*if(drive.getButton(F310.Button.LEFT_BUMPER)) {
			setLeft(-.2); //Sets left wheels to 1/5 speed if left bumper is pressed
		}
		if (drive.getButton(F310.Button.RIGHT_Y)) {
			setRight(.2); //Sets right wheels to 1/5 speed if right bumper is pressed
		}
		if(drive.getButton(F310.Button.Y)) {
			set(.25,.25); //Sets to quarter speed on both left and right wheels if Y is pressed
		}*/
	}
	

	private double getMultiplier(F310 drive) {
		if(drive.getButton(F310.Button.LEFT_BUMPER)) {
			System.out.println("Left Bumper");
			return 0.125;
		}
		else if(drive.getButton(F310.Button.LEFT_TRIGGER)) {
			System.out.println("Left Trigger");
			return 0.5;
		}
		if(drive.getButton(F310.Button.RIGHT_BUMPER)) {
			System.out.println("Right Bumper");
			return 0.125;
		}
		else if(drive.getButton(F310.Button.RIGHT_TRIGGER)) {
			System.out.println("Right Trigger");
			return 0.5;
		}
		else{
			return 0.25;
		} 
			
	}	

	public void set(double left, double right) {
		setLeft(left);
		setRight(-right);
		//System.out.println("Left: "+left+" Right: "+right);
	}

	private void setLeft(double speed) {
		l1.set(speed);
		l2.set(speed);
		//System.out.println("Left: "+speed);
	}

	private void setRight(double speed) {
		r1.set(speed);
		r2.set(speed);
		//System.out.println("Right: "+speed);

	}

	public void auto() {
		// TODO Auto-generated method stub
		
	}
}
