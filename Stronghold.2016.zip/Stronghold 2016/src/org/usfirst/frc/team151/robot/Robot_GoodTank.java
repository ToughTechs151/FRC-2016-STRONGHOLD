package org.usfirst.frc.team151.robot; 
/** 
 * Working TankDrive Code  
 * @author Julia Zhang 
 * @author Maddie Esp 	
 * @author Ruthra Govindaraj 
 * @version 02-04-2016 
 */ 
/** 
 * Pin 0 goes to motor 1 
 * Pin 1 goes to motor 2 
 * Pin 2 goes to motor 4 
 * Pin 3 goes to motor 3 
 */ 
import edu.wpi.first.wpilibj.SampleRobot;  
import edu.wpi.first.wpilibj.Joystick; 
import edu.wpi.first.wpilibj.RobotDrive; 
import edu.wpi.first.wpilibj.livewindow.LiveWindow; 


/** 
 * The VM is configured to automatically run this class, and to call the 
 * functions corresponding to each mode, as described in the IterativeRobot 
 * documentation. If you change the name of this class or the package after 
 * creating this project, you must also update the manifest file in the resource 
 * directory. 
 */ 
public class Robot_GoodTank extends SampleRobot { 
	RobotDrive myRobot; 
	Joystick driveStick; 
	int autoLoopCounter; 
	double y0, y1; 

	/** 
	 * This function is run when the robot is first started up and should be 
	 * used for any initialization code. 
	 */ 
	public void robotInit() { 
		myRobot = new RobotDrive(2, 4, 3, 5);
		driveStick = new Joystick(0); 
		y0 = 0.0; 
		y1=0.0; 

	} 

	/** 
	 * This function is run once each time the robot enters autonomous mode 
	 */ 
	public void autonomousInit() { 
		autoLoopCounter = 0; 
	} 

	/** 
	 * This function is called periodically during autonomous 
	 */ 
	public void autonomousPeriodic() { 
//		if(autoLoopCounter < 100) //Check if we've completed 100 loops (approximately 2 seconds) 
//		{ 
//			myRobot.drive(-0.5, 0.0); 	// drive forwards half speed 
//			autoLoopCounter++; 
//		} else { 
//			myRobot.drive(0.0, 0.0); 	// stop robot 
//		} 
	} 

	/** 
	 * This function is called once each time the robot enters tele-operated mode 
	 */ 
	public void teleopInit(){ 
	} 

	/** 
	 * This function is called periodically during operator control 
	 */ 
	public void teleopPeriodic() { 
		//Tank Drive 
		myRobot.tankDrive(driveStick.getRawAxis(1), driveStick.getRawAxis(3)); 


	} 

	/** 
	 * This function is called periodically during test mode 
	 */ 
	public void testPeriodic() { 
		LiveWindow.run(); 
	} 

} 
