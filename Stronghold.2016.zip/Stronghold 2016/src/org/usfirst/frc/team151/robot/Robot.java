package org.usfirst.frc.team151.robot;

import edu.wpi.first.wpilibj.SampleRobot; 
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;

import org.nashua.tt151.system.Arm;
//import org.nashua.tt151.system.ArcadeDrive;
import org.nashua.tt151.system.Subsystem;
import org.nashua.tt151.system.TankDrive;
import org.nashua.tt151.lib.F310;
import org.usfirst.frc.team151.robot.commands.ExampleCommand;
import org.usfirst.frc.team151.robot.subsystems.ExampleSubsystem;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
/**
 * @author Harrison Pound
 * @author Maddie Esp
 * @author Ruthra Govindaraj
 * @author Kareem El-Faramawi
 * 
 * @version 02-18-2016
/**
 * The VM is configured to automatically run this class, and to call the 
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends SampleRobot {
	
	public static final edu.wpi.first.wpilibj.command.Subsystem Subsystem = null;
	F310 drive = new F310(0, 0.1);
	F310 arm = new F310(1, 0.1);
	
	//public static OI oi;
	
    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
    @Override
    public void robotInit() {
        TankDrive.getInstance().init();
    }	
    
    @Override
    public void autonomous(){
    	TankDrive.getInstance().init();
    	TankDrive.getInstance().auto();
    }
    
    ;;;  ;;; ;;;   ;;;;;   ;;;;;           ;;    ;; ;;; ;;;;;;
    ;;;  ;;;       ;;; ;; ;; ;;;           ;;    ;;     ;;  ;;
    ;;;;;;;; ;;;   ;;;   ;;  ;;; ;;;;   ;;;;; ;;;;; ;;; ;;;;;;
    ;;;  ;;; ;;;   ;;;       ;;; ;  ;   ;  ;; ;  ;; ;;; ;; 
    ;;;  ;;; ;;;   ;;;       ;;; ;;;;;; ;;;;; ;;;;; ;;; ;;;;;;    
    
    public void operatorControl(){
    	TankDrive.getInstance().init();
    	//Arm.getInstance().init();
    	
    	while(isOperatorControl() && isEnabled()){
    		TankDrive.getInstance().operatorControl(drive, arm);
    		//Arm.getInstance().operatorControl(arm, drive);
    	}
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void test() {
        LiveWindow.run();
    }
    
    protected void disabled(){
    	TankDrive.getInstance().set(0.0, 0.0);
    	// Arm.getInstance().set(0, 0);
    }
}
